package com.cognizant.emedicare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmediCareApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmediCareApplication.class, args);
	}

}
